import { Slrfactory } from './slrfactory';

export class Slrbranches {
    id: number;
    smnemocode: string;
    snm: string;
    idfactory: Slrfactory;
}