export const environment = {
  production: true,
  REST_API_URL: 'http://localhost:9966/grinn/api/'

};
